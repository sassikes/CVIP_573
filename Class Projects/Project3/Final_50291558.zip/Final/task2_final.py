import cv2
import numpy as np
import matplotlib.pyplot as plt

point_kernal2=np.array([[0,-1,0],
                       [-1,4,-1],
                       [0,-1,0]])
x=0
y=0
def conv(img,kernal):
    result=np.zeros((img.shape[0],img.shape[1]))
    for i in range(1,img.shape[0]):
        for j in range(1,img.shape[1]):
            try:
                result[i][j]=(((kernal[0][0]*img[i-1][j-1])+
                                (kernal[0][1]*img[i-1][j])+
                                (kernal[0][2]*img[i-1][j+1])+
                                (kernal[1][0]*img[i][j-1])+
                                (kernal[1][1]*img[i][j])+
                                (kernal[1][2]*img[i][j+1])+
                                (kernal[2][0]*img[i+1][j-1])+
                                (kernal[2][1]*img[i+1][j])+
                                (kernal[2][2]*img[i+1][j+1])))
            except:
                continue
    return result

img=cv2.imread("point.jpg",0)
img2=conv(img,point_kernal2)

for i in range(0,img.shape[0]):
    for j in range(0,img.shape[1]):
        if(abs(img2[i][j])>=300):
            img2[i][j]=255
           
        else:
            img2[i][j]=0
            
for i in range(0,img2.shape[0]):
    for j in range(0,img2.shape[1]):
        if(abs(img2[i][j])==255):
             x=i
             y=j
loc="("+str(x)+","+str(y)+")"
cv2.putText(img2, loc,(x+150, y-220),cv2.FONT_HERSHEY_SIMPLEX,1, (255, 255, 255), 1, cv2.LINE_AA)	
           
#cv2.imshow("result1",img2)
#cv2.waitKey(0)
#cv2.destroyAllWindows()
cv2.imwrite("point_result.jpg",img2)


def dilate(img,kernal=np.ones((3,3))):
    result=np.zeros((img.shape[0],img.shape[1]))
    for i in range(0,img.shape[0]):
        for j in range(0,img.shape[1]):
            try:
                match=((kernal[0][0]*img[i-1][j-1])+
                                (kernal[0][1]*img[i-1][j])+
                                (kernal[0][2]*img[i-1][j+1])+
                                (kernal[1][0]*img[i][j-1])+
                                (kernal[1][1]*img[i][j])+
                                (kernal[1][2]*img[i][j+1])+
                                (kernal[2][0]*img[i+1][j-1])+
                                (kernal[2][1]*img[i+1][j])+
                                (kernal[2][2]*img[i+1][j+1]))
                if(match>=1):
                    result[i][j]=1
                else:
                    result[i][j]=0
            except:
                result[i][j]=0
                continue
    return result

segment=cv2.imread("segment.jpg",0)
pixel=np.zeros((256))
for a in range(0,segment.shape[0]):
    for b in range(0,segment.shape[1]):
        index=segment[a][b]
        if(segment[a][b]==0):
            continue
        pixel[index]+=1

plt.plot(pixel)
plt.show()



for a in range(0,segment.shape[0]):
    for b in range(0,segment.shape[1]):
        if(segment[a][b]<205):
            segment[a][b]=0
        else:
            segment[a][b]=255
                  
dilated_segment=dilate(segment)


x=[]
y=[]

for i in range(0,dilated_segment.shape[0]):
    for j in range(0,dilated_segment.shape[1]):
        if(dilated_segment[i][j]==1):
            y.append(j)

y.sort()
y=list(set(y))
y_w=[]
x_w=[]
for i in range(0,len(y)):
    try:
        if(i==0):
            y_w.append(y[i])
        if(y[i+1]-y[i]>10):
            y_w.append(y[i])
            y_w.append(y[i+1])
    except:
        y_w.append(y[-1])
        continue
    
y_w1=np.asarray(y_w).reshape(4,2)
y_w1=tuple(map(tuple, y_w1))

for i in range(0,len(y_w1)):
    start,end=y_w1[i]
    for j in range(0,dilated_segment.shape[0]):
        for k in range(start,end):
            if(dilated_segment[j][k]==1):
                x.append(j)
    x.sort()
    x_w.append(x[0])
    x_w.append(x[-1])
    x=[]

x_w1=np.asarray(x_w).reshape(4,2)
x_w1=tuple(map(tuple, x_w1))   
for i in range(0,len(x_w1)):
    dilated_segment = cv2.rectangle(dilated_segment,(y_w1[i][0],x_w1[i][0]),(y_w1[i][1],x_w1[i][1]),(255,255,255),1) 

def retouch(img):
    for i in range(0,img.shape[0]):
        for j in range(0,img.shape[1]):
            if(img[i][j]==1):
                img[i][j]=255
    return img

dilated_segment=retouch(dilated_segment)   
#cv2.imshow("segment1",dilated_segment)
#cv2.waitKey(0)
#cv2.destroyAllWindows()
cv2.imwrite("segment_result.png",dilated_segment)



for i in range(0,len(x_w1)):
    print("Co-ordinates of bounding box %d"%(i+1))
    print("(%d,%d)(%d,%d)(%d,%d)(%d,%d)"%(x_w1[i][0],y_w1[i][0],x_w1[i][0],y_w1[i][1],x_w1[i][1],y_w1[i][0],x_w1[i][1],y_w1[i][1]))