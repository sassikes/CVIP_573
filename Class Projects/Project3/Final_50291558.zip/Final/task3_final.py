import cv2
import numpy as np
import matplotlib.pyplot as plt

def erode(img, kernal=np.ones((3,3))):
    result=np.zeros((img.shape[0],img.shape[1]))
    for i in range(0, img.shape[0]):
        for j in range(0,img.shape[1]):
            try:
                match=((kernal[0][0]*img[i-1][j-1])+
                                (kernal[0][1]*img[i-1][j])+
                                (kernal[0][2]*img[i-1][j+1])+
                                (kernal[1][0]*img[i][j-1])+
                                (kernal[1][1]*img[i][j])+
                                (kernal[1][2]*img[i][j+1])+
                                (kernal[2][0]*img[i+1][j-1])+
                                (kernal[2][1]*img[i+1][j])+
                                (kernal[2][2]*img[i+1][j+1]))
                if(match>8):
                    result[i][j]=1
                else:
                    result[i][j]=0
            except:
                result[i][j]=0
                continue
    return result

def conv(img,kernal,T):
    result=np.zeros((img.shape[0],img.shape[1]))
    for i in range(1,img.shape[0]):
        for j in range(1,img.shape[1]):
            try:
                result[i][j]=(((kernal[0][0]*img[i-1][j-1])+
                                (kernal[0][1]*img[i-1][j])+
                                (kernal[0][2]*img[i-1][j+1])+
                                (kernal[1][0]*img[i][j-1])+
                                (kernal[1][1]*img[i][j])+
                                (kernal[1][2]*img[i][j+1])+
                                (kernal[2][0]*img[i+1][j-1])+
                                (kernal[2][1]*img[i+1][j])+
                                (kernal[2][2]*img[i+1][j+1])))
                if result[i][j]<T:
                    result[i][j]=0
                else:
                    result[i][j]=255
            except:
                #result[i][j]=0
                continue
    return result

img = cv2.imread('hough.jpg',0)
edges = cv2.Canny(img,100,200)
kernel = np.ones((3,3),np.uint8)
kernal_st=np.array([[-1,2,-1],[-1,2,-1],[-1,2,-1]])
kernal_45=np.array([[2,-1,-1],[-1,2,-1],[-1,-1,2]])
edges1=conv(edges,kernal_st,1510)
edges1=erode(edges1)
edges2=conv(edges,kernal_45,1000)
edges2=erode(edges2)
#Point   
def hough_transform(image):
    width = image.shape[1]
    height = image.shape[0]
    length = np.ceil(np.sqrt(width * width + height * height))
    rho_range = int(2*length)
    accu = np.zeros([rho_range, 180])
    j_indexes, i_indexes = np.nonzero(image)
    for k in range(len(j_indexes)):
        i = i_indexes[k]
        j = j_indexes[k]
        for theta in range(0, 180):
            rho = int(np.round(i * np.cos(np.deg2rad(theta)) + j * np.sin(np.deg2rad(theta))) + length)
            accu[rho, theta] += 1
    return accu

# Peak finding
def find_max_votes(accu, min_distance = 45, max_votes = 6,name="accumulator.jpg"):
#    coordinates=[]
#    temp=[]
#    sortd=np.sort(np.ndarray.flatten(accu))
#    sortd=sortd[-max_votes:]
#    for i in range(0,len(sortd)):
#        for j in range(0,accu.shape[0]):
#            for k in range(0,accu.shape[1]):
#                if(accu[j][k]==sortd[i]):
#                    #print(j," ",k)
#                    temp.append(j)
#                    temp.append(k)            
#        coordinates.append(temp)
#        temp=[]
#    coordinates=np.asarray(coordinates)
#    print(coordinates)
#    max_rhos = []
#    max_thetas = []
#    for i in range(len(coordinates)):
#        max_rhos.append(coordinates[i][0])
#        max_thetas.append(coordinates[i][1])
    from skimage.feature import peak_local_max
    coordinates = peak_local_max(accu, min_distance=min_distance,exclude_border = False, num_peaks =max_votes)
    max_rhos = coordinates[:, 0]
    max_thetas = coordinates[:, 1]
    plt.imshow(accu, cmap='gray',aspect='auto')
    plt.title("accumulator")
    #plt.savefig(name)
    return max_rhos, max_thetas

def draw_line(image, max_rhos, max_thetas, rgb = (0,255,0),name="edge.jpg"):
    image_copy = image.copy()
    width = image_copy.shape[1]
    height = image_copy.shape[0]
    length = np.ceil(np.sqrt(width * width + height * height)) 
    for j in range(len(max_rhos)):
        rho = max_rhos[j] - length
        theta = max_thetas[j]
        a = np.cos(np.deg2rad(theta))
        b = np.sin(np.deg2rad(theta))
        x1=int(a*rho - length*b) 
        y1=int(b*rho + length*a)
        x2=int(a*rho + length*b)
        y2=int(b*rho - length*a)
        cv2.line(image_copy, (x1,y1),(x2,y2), (255,0,0), 3)
        cv2.imwrite(name,image_copy)
    return image_copy

accu = hough_transform(edges1)
max_rhos, max_thetas = find_max_votes(accu, max_votes=6,name="vertical_accumulator.jpg")
draw_line(img, max_rhos, max_thetas,name="red_lines.jpg")
accu = hough_transform(edges2)
max_rhos, max_thetas = find_max_votes(accu, max_votes=9,name="diagonal_accumulator.jpg")
draw_line(img, max_rhos, max_thetas,name="blue_lines.jpg")