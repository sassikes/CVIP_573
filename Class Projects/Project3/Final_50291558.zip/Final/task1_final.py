import cv2
import numpy as np

def erode(img, kernal=np.ones((3,3))):
    result=np.zeros((img.shape[0],img.shape[1]))
    for i in range(0, img.shape[0]):
        for j in range(0,img.shape[1]):
            try:
                match=((kernal[0][0]*img[i-1][j-1])+
                                (kernal[0][1]*img[i-1][j])+
                                (kernal[0][2]*img[i-1][j+1])+
                                (kernal[1][0]*img[i][j-1])+
                                (kernal[1][1]*img[i][j])+
                                (kernal[1][2]*img[i][j+1])+
                                (kernal[2][0]*img[i+1][j-1])+
                                (kernal[2][1]*img[i+1][j])+
                                (kernal[2][2]*img[i+1][j+1]))
                if(match==9):
                    result[i][j]=1
                else:
                    result[i][j]=0
            except:
                result[i][j]=0
                continue
    return result

def dilate(img,kernal=np.ones((3,3))):
    result=np.zeros((img.shape[0],img.shape[1]))
    for i in range(0,img.shape[0]):
        for j in range(0,img.shape[1]):
            try:
                match=((kernal[0][0]*img[i-1][j-1])+
                                (kernal[0][1]*img[i-1][j])+
                                (kernal[0][2]*img[i-1][j+1])+
                                (kernal[1][0]*img[i][j-1])+
                                (kernal[1][1]*img[i][j])+
                                (kernal[1][2]*img[i][j+1])+
                                (kernal[2][0]*img[i+1][j-1])+
                                (kernal[2][1]*img[i+1][j])+
                                (kernal[2][2]*img[i+1][j+1]))
                if(match>=1):
                    result[i][j]=1
                else:
                    result[i][j]=0
            except:
                result[i][j]=0
                continue
    return result

def opening(img):
    return(dilate(erode(img)))
  
def closing(img):
    return(erode(dilate(img)))

def retouch(img):
    for i in range(0,img.shape[0]):
        for j in range(0,img.shape[1]):
            if(img[i][j]==1):
                img[i][j]=255
    return img
    
img=cv2.imread("noise.jpg",0)
img=img/255
res_noise1=closing(opening(img))
res_noise2=opening(closing(img))
res_bound1=res_noise1-erode(res_noise1)
res_bound2=res_noise2-erode(res_noise2)
res_noise1=retouch(res_noise1)
res_noise2=retouch(res_noise2)
res_bound1=retouch(res_bound1)
res_bound2=retouch(res_bound2)

cv2.imwrite("res_noise1.jpg",res_noise1)
cv2.imwrite("res_noise2.jpg",res_noise2)
cv2.imwrite("res_bound1.jpg",res_bound1)
cv2.imwrite("res_bound2.jpg",res_bound2)

