
# coding: utf-8

# In[15]:


import numpy as np
from matplotlib import pyplot as plt
import cv2
import math


# In[16]:
UBIT = 'sassikes'
np.random.seed(sum([ord(c) for c in UBIT]))

#Setting Values of datapoints, mu value and cluster size
x=[5.9,4.6,6.2,4.7,5.5,5,4.9,6.7,5.1,6]
y=[3.2,2.9,2.8,3.2,4.2,3,3.1,3.1,3.8,3]
X = np.array(list(zip(x, y)), dtype=np.float32)
k = 3
C_x=[6.2,6.6,6.5]
C_y=[3.2,3.7,3.0]
C=np.array([[6.2,3.2],[6.6,3.7],[6.5,3.0]])


# In[17]:


# EUCLIDEAN DISTANCE
def dist(l, m, ax=1):
    return np.linalg.norm(l - m, axis=ax)


# In[18]:


# GROUPING THE POINTS BASED ON INITIAL CENTROIDS
C_old = C
clusters = np.zeros(len(X))
for i in range(len(X)):
        distances = dist(X[i], C)
        cluster = np.argmin(distances)
        clusters[i] = cluster

colors = ['r', 'b', 'g']
fig, ax = plt.subplots()
for i in range(k):
        points = np.array([X[j] for j in range(len(X)) if clusters[j] == i])
        ax.scatter(points[:, 0], points[:, 1], marker='^', s=70, c=colors[i])
        #plt.scatter(x, y, marker='^', c='black', s=100)
ax.scatter(C[:, 0], C[:, 1], marker='.', s=200, c=colors)
fig.savefig("task3_iter1_a.jpg")


# In[19]:


# UPDATING AND STORING THE VALUES OF CENTROIDS
C_old = np.zeros(C.shape)
clusters = np.zeros(len(X))
error = dist(C, C_old, None)

for i in range(len(X)):
        distances = dist(X[i], C)
        cluster = np.argmin(distances)
        clusters[i] = cluster

for i in range(k):
        points = [X[j] for j in range(len(X)) if clusters[j] == i]
        C[i] = np.mean(points, axis=0)
error = dist(C, C_old, None)


# In[20]:


colors = ['r', 'b', 'g']
fig, ax = plt.subplots()
for i in range(k):
        points = np.array([X[j] for j in range(len(X)) if clusters[j] == i])
        ax.scatter(points[:, 0], points[:, 1], marker='^', s=100, c=colors[i])
ax.scatter(C[:, 0], C[:, 1], marker='.', s=150, c=colors)
fig.savefig("task3_iter1_b.jpg")


# In[21]:


#SECOND ITERATION 
for i in range(len(X)):
        distances = dist(X[i], C)
        cluster = np.argmin(distances)
        clusters[i] = cluster

# Recomputing means
for i in range(k):
        points = [X[j] for j in range(len(X)) if clusters[j] == i]
        C[i] = np.mean(points, axis=0)
#error = dist(C, C_old, None)


# In[22]:


colors = ['r', 'b', 'g']
fig, ax = plt.subplots()
for i in range(k):
        points = np.array([X[j] for j in range(len(X)) if clusters[j] == i])
        ax.scatter(points[:, 0], points[:, 1], marker='^', s=70, c=colors[i])
        #plt.scatter(x, y, marker='^', c='black', s=100)
fig.savefig("task3_iter2_a.jpg")
ax.scatter(C[:, 0], C[:, 1], marker='.', s=150, c=colors)
fig.savefig("task3_iter2_b.jpg")


# In[23]:


colors = ['r', 'b', 'g']
fig, ax = plt.subplots()
for i in range(k):
        points = np.array([X[j] for j in range(len(X)) if clusters[j] == i])
        ax.scatter(points[:, 0], points[:, 1], marker='^', s=70, c=colors[i])
        #plt.scatter(x, y, marker='^', c='black', s=100)
ax.scatter(C[:, 0], C[:, 1], marker='.', s=150, c=colors)


# In[ ]:


#COLOR QUANTIZATION USING K-MEANS
def mu_gen(n):
    mu = []
    for i in range(n):
        r,g,b = np.random.randint(0,255),np.random.randint(0,255),np.random.randint(0,255)
        mu.append([r,g,b])
    return mu


def clusteringpluscentroids(points, centroids, iterations):
    for i in range(iterations):
        listrgb = [[] for zxc in range(n)]
        for point in points:
            dists = []
            for centroid in centroids:
                dist = (centroid[0] - point[0])**2 + (centroid[1] - point[1])**2 + (centroid[2] - point[2])**2
                dist = math.sqrt(dist)
                dists.append(dist)
            mindist = min(dists)
            listrgb[dists.index(mindist)].append(point)

        centroids = []

        for listx in listrgb:
            x,y,z = 0,0,0
            for point in listx:
                x = x + point[0]
                y = y + point[1]
                z = z + point[2]
            try:
                x = x/len(listx)
                y = y/len(listx)
                z = z/len(listx)
            except:
                continue
            centroids.append([x,y,z])
    return centroids, listrgb

cluster_size=[3,5,10,20]
for n in cluster_size:
    centroids = mu_gen(int(n))
    image = cv2.imread('baboon.jpg')
    temp=image.copy()
    points = []
    for row in image:
        for pixel in row:
            r,g,b = pixel[0],pixel[1],pixel[2]
            points.append([r,g,b])
    iterations = 10
    centroids, listrgb = clusteringpluscentroids(points, centroids, iterations)
    print("interations done for cluster size ",n)
    img = image
    for row in range(len(image)):
        for column in range(len(image[0])):
            point = [image[row,column,0],image[row,column,1],image[row,column,2]]
            dists = []
            for centroid in centroids:
                dist = (centroid[0] - point[0])**2 + (centroid[1] - point[1])**2 + (centroid[2] - point[2])**2
                dist = math.sqrt(dist)
                dists.append(dist)
            mindist = min(dists)
            inde = dists.index(mindist)
            img[row,column,0],img[row,column,1],img[row,column,2] = centroids[inde][0],centroids[inde][1],centroids[inde][2]
    filename="task3_baboon_"+str(n)+".jpg"
    cv2.imwrite(filename, np.hstack([temp, img]))

