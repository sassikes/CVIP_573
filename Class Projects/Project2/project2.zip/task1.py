
# coding: utf-8

# In[104]:


import numpy as np
import cv2


# In[105]:


UBIT = 'sassikes'
np.random.seed(sum([ord(c) for c in UBIT]))


# In[106]:


#Reading input images
img1=cv2.imread("mountain1.jpg")
img2=cv2.imread("mountain2.jpg")
temp1=img1.copy()
temp2=img2.copy()
gray1= cv2.cvtColor(img1,cv2.COLOR_BGR2GRAY)
gray2= cv2.cvtColor(img2,cv2.COLOR_BGR2GRAY)

#Finding Key points using SIFT
sift = cv2.xfeatures2d.SIFT_create()
kp1, des1 = sift.detectAndCompute(gray1,None)
kp2, des2 = sift.detectAndCompute(gray2,None)
img1=cv2.drawKeypoints(img1,kp1,None,color=(255,0,100))
img2=cv2.drawKeypoints(img2,kp2,None,color=(255,0,100))


# In[107]:


#Finding Key points in the two images
FLANN_INDEX_KDTREE = 0
index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
search_params = dict(checks = 50)
flann = cv2.FlannBasedMatcher(index_params, search_params)
matches = flann.knnMatch(des1,des2,k=2)
good = []
for m,n in matches:
    if m.distance < 0.7*n.distance:
        good.append(m)
task1_matches_knn=cv2.drawMatches(img1,kp1,img2,kp2,good,None,matchColor=(0,0,0),singlePointColor=(0,0,255))


# In[108]:


#Finding Homography matrix
src_pts = np.float32([ kp1[m.queryIdx].pt for m in good ]).reshape(-1,1,2)
dst_pts = np.float32([ kp2[m.trainIdx].pt for m in good ]).reshape(-1,1,2)
M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC,5.0)
invM=np.linalg.inv(M)
homography=np.asarray(M)


# In[109]:


#Finding and mapping 10 inliner points
matchesMask = mask.ravel().tolist()
m=np.random.randint(0,len(matchesMask),10)
task1_matches = cv2.drawMatches(img1,kp1,img2,kp2,np.random.choice(good,10),None,matchColor=(0,0,0),singlePointColor=(0,0,255),matchesMask=m.tolist())


# In[110]:


#Creating a pano by merging two images
rows1, cols1 = temp1.shape[:2]
rows2, cols2 = temp2.shape[:2]

lp1 = np.float32([[0,0], [0,rows1], [cols1, rows1], [cols1,0]]).reshape(-1,1,2)
temp = np.float32([[0,0], [0,rows2], [cols2, rows2], [cols2,0]]).reshape(-1,1,2)

lp2 = cv2.perspectiveTransform(temp, M)
lp = np.concatenate((lp1, lp2), axis=0)

[x_min, y_min] = np.int32(lp.min(axis=0).ravel() - 0.5)
[x_max, y_max] = np.int32(lp.max(axis=0).ravel() + 0.5)

translation_dist = [-x_min, -y_min]
H_translation = np.array([[1, 0, translation_dist[0]], [0, 1, translation_dist[1]], [0,0,1]])

result = cv2.warpPerspective(temp1, H_translation.dot(M), (x_max+50 - x_min+50, y_max+50 - y_min+50))
result[translation_dist[1]:rows1+translation_dist[1],translation_dist[0]:cols1+translation_dist[0]] = temp2


# In[111]:


#Writing the results
print(homography)
cv2.imwrite("task1_sift1.jpg",img1)
cv2.imwrite("task1_sift2.jpg",img2)
cv2.imwrite("task1_matches_knn.jpg",task1_matches_knn)
cv2.imwrite("task1_matches.jpg",task1_matches)
cv2.imwrite("task1_pano.jpg",result)

